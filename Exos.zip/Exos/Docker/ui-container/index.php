
<html>
    <head>
        <title> Prediction</title>
    </head>

    <body>
        <h1>Bonjour</h1>
        <ul>
            <?php
            $json = file_get_contents('http://algo-container/');
            $obj = json_decode($json);
            $galaxies = $obj->Galaxies;
            foreach ($galaxies as $galaxy) {
                echo "<li>$galaxy</li>";
            }
            ?>
        </ul>
    </body>
</html>
